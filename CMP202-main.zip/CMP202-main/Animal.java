package OOP;
public class Animal {
    String name;
    String move(){
        return "Moves by walking";
    }
    boolean isALive(){
        return true;
    }


}
